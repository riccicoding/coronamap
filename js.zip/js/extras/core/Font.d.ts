export class Font {

	constructor( jsondata: any );

	data: string;

	generateShapes( text: string, size: number, divisions: number ): any[];

}
